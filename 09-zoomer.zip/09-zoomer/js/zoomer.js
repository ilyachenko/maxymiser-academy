function addEvent(obj, event_name, handler) {
    var handler_wrapper = function(event) {
        event = event || window.event;
        if (!event.target && event.srcElement) {
            event.target = event.srcElement;
        }
        return handler.call(obj, event);
    };

    if (obj.addEventListener) {
        obj.addEventListener(event_name, handler_wrapper, false);
    } else if (obj.attachEvent) {
        obj.attachEvent('on' + event_name, handler_wrapper);
    }
    return handler_wrapper;
}

function makeZoomable(node){

    if(!document.getElementById("popup_wrapper")){
        var newElement = '<div id="popup_wrapper" style="display: none;"><div id="popup"><p id="closeBtn">Закрыть</p><img src="" /></div><div id="parent_popup"></div></div>';
        document.body.innerHTML = newElement + document.body.innerHTML;
    }

    var imgs = node.getElementsByTagName('img');
    if (imgs.length == 0) return;
    for(var i=0; i<imgs.length; i++){
        var img = imgs[i];
        console.log(img);
        addEvent(img, 'click', showBigger);
    }
}

//показать увеличенную картинку и затемнение
var showBigger = function (){
    console.log('123');

//    var s = this.getAttribute('src');
//    var re = /small/g;
//    var result = s.replace(re, "large");
//
//    document.getElementById("popup_wrapper").style.display = "block";

//    var closeBtn = document.getElementById("closeBtn");
//    addEvent(closeBtn, 'click', closeDiv);
};

//удаляет DIV`ы с увеличенной картинкой и затемнением
var closeDiv = function (){
    console.log('123');
//    var popup = document.getElementById("popup");
//    var parent_popup = document.getElementById("parent_popup");
//    popup.remove();
//    parent_popup.remove();
}

//для удаления в ИЕ8
Element.prototype.remove = function() {
    this.parentElement.removeChild(this);
}

